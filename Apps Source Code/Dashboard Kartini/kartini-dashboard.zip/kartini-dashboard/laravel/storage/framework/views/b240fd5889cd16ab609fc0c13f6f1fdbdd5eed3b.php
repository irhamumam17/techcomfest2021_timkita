<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
    <div class="profile-sidebar">
        <div class="profile-userpic">
            <img src="http://placehold.it/50/30a5ff/fff" class="img-responsive" alt="">
        </div>
        <div class="profile-usertitle">
            <div class="profile-usertitle-name"><?php echo e(request()->user['nama']); ?></div>
            <div class="profile-usertitle-status"><span class="indicator label-success"></span>Online</div>
        </div>
        <div class="clear"></div>
    </div>
    <div class="divider"></div>
    
    <ul class="nav menu">
        <?php if(request()->user['role']== 1): ?>
        <li class="<?php echo e($action=='index'?'active':''); ?>"><a href="/firebase"><em class="fa fa-bar-chart">&nbsp;</em> Verifikasi Kasus</a></li>
        <li class="<?php echo e($action=='filter'?'active':''); ?>"><a href="http://localhost:8000/firebase/filter">
            <em class="fa fa-navicon">&nbsp;</em> Filter Kasus 
            </a>
        </li>
        <?php elseif(request()->user['role']== 2): ?>
        <li class="<?php echo e($action=='filter'?'active':''); ?>"><a href="http://localhost:8000/firebase/polisi">
            <em class="fa fa-navicon">&nbsp;</em> Filter Kasus 
            </a>
        </li>
        <?php elseif(request()->user['role']== 3): ?>
        <li class="<?php echo e($action=='filter'?'active':''); ?>"><a href="http://localhost:8000/firebase/polisi">
            <em class="fa fa-navicon">&nbsp;</em> Filter Kasus 
            </a>
        </li>
        
        <?php endif; ?>


        

        <li><a href="/login"><em class="fa fa-power-off">&nbsp;</em> Logout</a></li>
    </ul>
</div><?php /**PATH C:\Users\Ibnu Adam\Documents\KULIAH\Semester 5\Manajemen Sistem I‌nformasi\kartini-laravel\laravel\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>